
let penaltyScale, dogCatScale;

function preload() {
    //pictures
    penalty = loadImage('images/visual 1.png');
    dogCat = loadImage('images/node-3009-1024x536.png');
    adoptButton = loadImage('images/adopt.png');
}

function setup() {
    let myCanvas = createCanvas(innerWidth, innerHeight);
    myCanvas.position(0, 0);
    imageMode(CENTER);
    textAlign(CENTER);
    background('#FFDEB3');

    button = createImg('images/adopt.png');

    penaltyScale = penalty.width / penalty.height;
    dogCatScale = dogCat.width / dogCat.height;
}

function draw() {
    background('#FFDEB3');

    let picSize1 = height / 3.5;
    let picSize2 = height / 3.33;

    image(penalty, width / 2, height / 2.8, picSize1 * penaltyScale, picSize1);
    image(dogCat, width / 2, height / 2.8 + picSize1 + 20, picSize2 * dogCatScale, picSize2);

    textSize(35);
    text("I DON'T HAVE HOME,  IF YOU LIKE ME,  PLEASE TAKE ME HOME ", width / 2, height / 10 + 60);


    button.position(width / 2 - adoptButton.width / 2, height - height / 8);
    button.mouseOver(function () {
        button.size(adoptButton.width * 1.1, AUTO);
    });
    button.mouseOut(function () {
        button.size(adoptButton.width, AUTO);
    });
    // button.mouseClicked(function () {
    //     window.location.href = 'dog.html';
    // });
}


function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}


