//poseNet
let video;
let pose;

let buttonPos;
let buttonSize = 50;
let Hovered = false;

let Timer = 0;

//rain
var drop = [];
var splash = [];
var g = 0.14;
var heavy = 150;

//lighting
var incrFlashTime; // increment through from 0 to flashTime
var flashTime; // time length of each individual flash
var flashGroupTime; // time length of each group of flashes
var howOften; // time between groups 

function preload() {
    //pictures
    catHead = loadImage('images/1.png');
    leftHand = loadImage('images/2.png');
    rightHand = loadImage('images/RightH.png');
    leftFoot = loadImage('images/leftF.png');
    rightFoot = loadImage('images/RightF.png');
    moreButton = loadImage('images/more.png');

    //sound
    rainSound = loadSound('sound/f-18-9-18-07.mp3');
}

function setup() {
    let myCanvas = createCanvas(innerWidth, innerHeight);
    myCanvas.position(0, 0);
    imageMode(CENTER);
    textAlign(CENTER);
    background('#FFDEB3');

    button = createImg('images/more.png');
    button.hide();

    //poseNet
    video = createCapture(VIDEO);
    video.size(320, 240);
    video.position(0, 0);
    video.hide();
    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)

    buttonPos = createVector(width / 2, height - 150);

    //rainy  reference : https://openprocessing.org/sketch/977667
    for (let i = 0; i < heavy; i++) {
        var t = new Rain();
        drop.push(t);
    }

    rainSound.play();

}

function draw() {
    background('#FFDEB3');

    buttonPos = createVector(width / 2, height - 150);

    //sheetFlash
    push();
    howOften = floor(random(100, 110));
    if (frameCount % howOften === 0) {
        flashGroupTime = random(0, 15); // but not every time
    }
    if (flashGroupTime > 0) sheetFlash();
    pop();

    if (pose) {

        let d = dist(pose.leftEye.x, pose.leftEye.y, pose.rightEye.x, pose.rightEye.y);
        let scale = map(d, 0, 90, 0, 1);
        let HeadPoseX = map(pose.nose.x, 0, 320, width, 0);
        let HeadPoseY = map(pose.nose.y, 0, 240, 0, height / 2);

        let LeftHandX = map(pose.leftWrist.x, 0, 320, width, 0);
        let LeftHandY = map(pose.leftWrist.y, 0, 240, 0, height);
        let RightHandX = map(pose.rightWrist.x, 0, 320, width, 0);
        let RightHandY = map(pose.rightWrist.y, 0, 240, 0, height);
        image(catHead, HeadPoseX, HeadPoseY, catHead.width * 4 * scale, catHead.height * 4 * scale);
        image(leftHand, LeftHandX, LeftHandY, leftHand.width * scale * 4, leftHand.height * scale * 4);
        image(rightHand, RightHandX, RightHandY, rightHand.width * scale * 4, rightHand.height * scale * 4);

        if (dist(RightHandX, RightHandY, buttonPos.x, buttonPos.y) <= buttonSize) {
            Hovered = true;
            buttonSize = 60;

        } else {
            buttonSize = 50;
            Hovered = false;
        }
    }

    textSize(35);
    if (Hovered) {

        Timer++;
        let t = int(map(Timer, 0, 100, 0, 1));
        text("Please Hold On", width / 2, height / 10);
        text(t, width / 2, height / 10 + 60);

        if (t >= 5) {
            window.location.href = 'adopt.html';
        }

    } else {
        text("Please move your body !", width / 2, height / 10);
        text("I DON'T HAVE HOME,  IF YOU LIKE ME,  PLEASE TAKE ME HOME ", width / 2, height / 10 + 60);
    }


    let buttonSacle = moreButton.width / moreButton.height;
    image(moreButton, buttonPos.x, buttonPos.y, buttonSacle * buttonSize, buttonSize);

    button.position(width / 2 - moreButton.width / 2, height - 150);
    button.mouseOver(function () {
        button.size(moreButton.width * 1.1, AUTO);
    });
    button.mouseOut(function () {
        button.size(moreButton.width, AUTO);
    });
    button.mouseClicked(function () {
        window.location.href = 'adopt.html';
    });

    //rain && splash
    for (var i = 0; i < drop.length; i++) {
        drop[i].display();
        drop[i].fall();
        if (drop[i].y >= height) {
            splash.push(new Splash(drop[i].x));
            drop[i].reset();
        }
    }

    for (i = 0; i < splash.length; i++) {
        splash[i].fade();
        splash[i].display();

        if (splash[i].over()) {
            splash.splice(i, 1);
            i--;
        }
    }
}

function sheetFlash() {
    flashGroupTime--;
    incrFlashTime++;
    flashTime = random(0, 10); // not every time
    if (incrFlashTime < flashTime) {
        fill(255);
        noStroke();
        rect(0, 0, width, height);
    }
    else {
        incrFlashTime = 0;
    }
}


function modelLoaded() {
    console.log("modelLoaded function has been called so this work!!!!");
};

function gotPoses(poses) {

    if (poses.length > 0) {
        pose = poses[0].pose;
        skeleton = poses[0].skeleton;
        //print(pose);
    }
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}


