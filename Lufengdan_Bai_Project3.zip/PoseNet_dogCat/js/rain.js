function Rain() {

    this.x = random(-300, width + 300);
    this.y = random(-1400, -200);
    this.long = 30 + random(-10, 10);
    this.speed = 0;
    this.angle = 0;

    this.display = function () {
        line(this.x, this.y, this.x + this.long * sin(this.angle), this.y + this.long * cos(this.angle));
    }

    this.fall = function () {
        this.angle = map(mouseX - 300, -300, 300, -PI / 12, PI / 12);
        this.y += this.speed * cos(this.angle);
        this.x += this.speed * sin(this.angle);
        this.speed += g;
    }

    this.reset = function () {
        this.x = random(-300, width + 300);
        this.y = random(-800, -200);
        this.speed = 11;
    }

}