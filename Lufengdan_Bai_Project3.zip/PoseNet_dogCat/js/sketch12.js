let video;
let pose;
let skeleton;

let RaiseHands = false;

//https://openprocessing.org/sketch/1180528
let g;
let LeftParticles = [];
let RightParticles = [];

function preload() {
    //pictures
    head = loadImage('images/head.png');
    nose = loadImage('images/Nose1.png');
    leftEye = loadImage('images/leftEye.png');
    rightEye = loadImage('images/rightEye.png');
    mouse = loadImage('images/Mouse.png');
    rib = loadImage('images/rib.png');

    //sound
    soundFormats('mp3', 'ogg');
    fire = loadSound('sound/fire.mp3');
}

function setup() {

    createCanvas(640, 480);
    noStroke();
    video = createCapture(VIDEO);
    video.size(width, height);

    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)
    video.hide();

    rectMode(CENTER);
    angleMode(DEGREES);

    //particles
    g = createGraphics(32, 32);
    g.colorMode(HSB, 360, 100, 100, 100);
    g.noStroke();
    g.fill(255, 50);
    g.drawingContext.shadowColor = color(255);
    g.drawingContext.shadowBlur = g.width / 1.7;
    g.ellipse(g.width / 2, g.height / 2, g.width / 2.5);
}

function modelLoaded() {
    console.log("modelLoaded function has been called so this work!!!!");
};


function gotPoses(poses) {

    if (poses.length > 0) {
        pose = poses[0].pose;
        skeleton = poses[0].skeleton;
        print(pose);
    }
}

function draw() {

    image(video, 0, 0, width, height);
    //TRESHOLD 0 is white  1 is black
    filter(THRESHOLD, 1);

    if (pose) {

        let NosePos = pose.nose;
        let leftEyePos = pose.leftEye;
        let rightEyePos = pose.rightEye;
        let leftEar = pose.leftEar;
        let rightEar = pose.rightEar;

        let d = dist(pose.leftEye.x, pose.leftEye.y, pose.rightEye.x, pose.rightEye.y);
        let scale = map(d, 0, 90, 0, 1);

        for (let i = 0; i < pose.keypoints.length; i++) {

            let x = pose.keypoints[i].position.x;
            let y = pose.keypoints[i].position.y;

            push();
            fill(255);
            circle(x, y, 25);
            pop();

            push();
            for (let i = 0; i < skeleton.length; i++) {
                let a = skeleton[i][0];
                let b = skeleton[i][1];
                strokeWeight(5);
                stroke(255);
                line(a.position.x, a.position.y, b.position.x, b.position.y);
                fill(127);
            }
            pop();
        }


        let p1 = new Particle(leftEar.x, leftEar.y);
        let p2 = new Particle(rightEar.x, rightEar.y);
        LeftParticles.push(p1);
        RightParticles.push(p2);


        if (pose.keypoints[10].position.y < pose.keypoints[6].position.y
            && pose.keypoints[9].position.y < pose.keypoints[5].position.y) {
            RaiseHands = true;
        } else {
            RaiseHands = false;
        }


        //rib
        push();
        let LeftShoulder = createVector(pose.keypoints[5].position.x, pose.keypoints[5].position.y);
        let RightShoulder = createVector(pose.keypoints[6].position.x, pose.keypoints[6].position.y);
        imageMode(CENTER);
        let angle = Math.atan2(LeftShoulder.y - RightShoulder.y, LeftShoulder.x - RightShoulder.x) * (180 / Math.PI);
        translate((LeftShoulder.x + RightShoulder.x) / 2, (LeftShoulder.y + RightShoulder.y) / 2);
        rotate(angle);
        let ribScale = rib.width / rib.height;
        let ribPicHeight = rib.height * scale
        let ribPicWidth = ribPicHeight * ribScale;
        image(rib, 0, ribPicHeight / 4, ribPicWidth, ribPicHeight);
        pop();

        push();
        imageMode(CENTER);
        push();
        //head
        let headScale = head.width / head.height;
        let headPicHeight = head.height * scale
        let headPicWidth = headPicHeight * headScale;
        let rotateAngle = Math.atan2(leftEyePos.y - rightEyePos.y, leftEyePos.x - rightEyePos.x) * (180 / Math.PI);
        //  print(rotateAngle);
        translate(NosePos.x, NosePos.y);
        rotate(rotateAngle);
        image(head, 0, - headPicHeight / 6, headPicWidth, headPicHeight);

        //nose
        let noseScale = nose.width / nose.height;
        let nosePicHeight = nose.height * scale
        let nosePicWidth = nosePicHeight * noseScale;
        image(nose, 0, 0, nosePicWidth, nosePicHeight);

        //mouse
        let mouseScale = mouse.width / mouse.height;
        let mousePicHeight = mouse.height * scale
        let mousePicWidth = mousePicHeight * mouseScale;
        image(mouse, headPicHeight / 25, headPicHeight / 8, mousePicWidth, mousePicHeight);
        pop();

        //leftEye
        let leftEyeScale = leftEye.width / leftEye.height;
        let leftEyePicHeight = leftEye.height * scale
        let leftEyePicWidth = leftEyePicHeight * leftEyeScale;
        image(leftEye, leftEyePos.x, leftEyePos.y, leftEyePicWidth, leftEyePicHeight);

        //rightEye
        let rightEyeScale = rightEye.width / rightEye.height;
        let rightEyePicHeight = rightEye.height * scale
        let rightEyePicWidth = rightEyePicHeight * rightEyeScale;
        image(rightEye, rightEyePos.x, rightEyePos.y, rightEyePicWidth, rightEyePicHeight);

        pop();
    }

    //particles
    if (RaiseHands) {
        for (let i = LeftParticles.length - 1; i >= 0; i--) {
            LeftParticles[i].update();
            LeftParticles[i].show();
            if (LeftParticles[i].finished()) {
                LeftParticles.splice(i, 1);
            }
        }

        for (let i = RightParticles.length - 1; i >= 0; i--) {
            RightParticles[i].update();
            RightParticles[i].show();
            if (RightParticles[i].finished()) {
                RightParticles.splice(i, 1);
            }
        }

        //sound play
        if (!fire.isPlaying()) {
            fire.play();
        }

    } else {
        //sound stop
        if (fire.isPlaying()) {
            fire.stop();
        }
    }
}