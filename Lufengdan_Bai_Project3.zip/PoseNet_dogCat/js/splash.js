function Splash(x) {
    this.x = x;
    this.a = 0;
    this.b = 0;
    this.l = 5 + random(13);
    this.offset = random(5);

    this.display = function () {
        line(this.x - this.a, height - this.offset - this.a, this.x - this.b, height - this.offset - this.b);
        line(this.x + this.a, height - this.offset - this.a, this.x + this.b, height - this.offset - this.b);
    }

    this.fade = function () {
        if (this.b < this.l) {
            this.b += 4;
        } else if (this.a < this.l) {
            this.a += 4;
        }
    }

    this.over = function () {
        if (this.a >= this.l && this.b >= this.l) {
            return 1;
        } else {
            return 0;
        }
    }

}