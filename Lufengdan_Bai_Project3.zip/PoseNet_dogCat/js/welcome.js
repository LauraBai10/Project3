let header, dog, cat, dogButton, catButton;
let headerScale, dogScale, catScale;
let headerSize, dogSize, catSize;
let dogPos, catPos;
let dogHover, catHover;

let DogTimer = 0;
let CatTimer = 0;

//poseNet
let video;
let pose;

function preload() {
    //pictures
    header = loadImage('images/0a8c6a97f62bc02a71165ae4f9f97ab6.png');
    button = loadImage('images/矩形 2.png');
    dog = loadImage('images/5.png');
    cat = loadImage('images/6.png');
}

function setup() {
    let myCanvas = createCanvas(innerWidth, innerHeight);
    myCanvas.position(0, 0);
    imageMode(CENTER);
    textAlign(CENTER);
    background('#FFDEB3');

    //poseNet
    video = createCapture(VIDEO);
    video.size(320, 240);
    video.position(0, 0);
    video.hide();
    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)

    //imgScale
    headerScale = header.width / header.height;
    headerSize = height / 3;
    dogScale = dog.width / dog.height;
    dogSize = 240;
    catScale = cat.width / cat.height;
    catSize = 240;

    //buttons
    dogButton = createImg('images/dogButton.png');
    catButton = createImg('images/catButton.png');

    dogPos = createVector(width / 2 - 15 - width / 4, height / 1.4);
    catPos = createVector(width / 2 - 15 + width / 4, height / 1.4);


}

function draw() {
    background('#FFDEB3');
    //welcomeHeader
    image(header, width / 2, height / 6, headerSize * headerScale, headerSize);
    image(dog, dogPos.x, dogPos.y, dogSize * dogScale, dogSize);
    image(cat, catPos.x, catPos.y, catSize * catScale, catSize);
    //pick button
    // image(button, width / 2 - width / 4, height / 1.17);
    //  image(button, width / 2 + width / 4, height / 1.17);

    textSize(35);
    if (catHover) {
        DogTimer++;
        let t = int(map(DogTimer, 0, 100, 0, 1));
        text("Please Hold On", width / 2, height / 2.3);
        text(t, width / 2, height / 2);

        if (t >= 5) {
            window.location.href = 'cat.html';
        }

    } else if (dogHover) {

        CatTimer++;
        let t = int(map(CatTimer, 0, 100, 0, 1));
        text("Please Hold On", width / 2, height / 2.3);
        text(t, width / 2, height / 2);

        if (t >= 5) {
            window.location.href = 'dog.html';
        }

    } else {
        DogTimer = 0;
        CatTimer = 0;
        text("Do you want to know more about my story ?", width / 2, height / 2.3);
        text("Please pick and become me !", width / 2, height / 2);
    }



    //text("Pick dog!", width / 2 - width / 4, height / 1.155);
    //text("Pick cat!", width / 2 + width / 4, height / 1.155);

    if (pose) {
        let rightWristX = map(pose.rightWrist.x, 0, 320, width, 0);
        let rightWristY = map(pose.rightWrist.y, 0, 240, 0, height);
        push();
        noStroke();
        fill(255, 0, 0);
        circle(rightWristX, rightWristY, 50);
        pop();


        //dog hover Event
        if (dist(rightWristX, rightWristY, dogPos.x, dogPos.y) < dogSize) {
            dogHover = true;
            dogSize = 250;
        } else {
            dogHover = false;
            dogSize = 240;
        }

        //cat hover Event
        if (dist(rightWristX, rightWristY, catPos.x, catPos.y) < catSize) {
            catHover = true;
            catSize = 250;
            timer++;
        } else {
            catHover = false;
            catSize = 240;
            timer = 0;
        }
    }


    dogButton.position(width / 2 - button.width / 2 - width / 4, height / 1.4 + dogSize / 2);
    catButton.position(width / 2 - button.width / 2 + width / 4, height / 1.4 + catSize / 2);

    dogButton.mouseOver(function () {
        dogSize = 250;
    });
    dogButton.mouseOut(function () {
        dogSize = 240;
    });
    dogButton.mouseClicked(function () {
        window.location.href = 'dog.html';
    });

    catButton.mouseOver(function () {
        catSize = 250;
    })
    catButton.mouseOut(function () {
        catSize = 240;
    });
    catButton.mouseClicked(function () {
        window.location.href = 'cat.html';
    });


}

function modelLoaded() {
    console.log("modelLoaded function has been called so this work!!!!");
};

function gotPoses(poses) {

    if (poses.length > 0) {
        pose = poses[0].pose;
        skeleton = poses[0].skeleton;
        //print(pose);
    }
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}